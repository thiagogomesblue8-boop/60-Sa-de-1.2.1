# 60+ Saúde — Versão 1.2 (Android e PWA)

## Problema corrigido
O app baixado do WhatsApp abre em `content://` e não oferece acesso confiável à API de reconhecimento de voz. O botão agora apresenta um diagnóstico claro para arquivo local, página HTTP sem segurança, navegador incompatível e erros de permissão.

## Como publicar em HTTPS
1. Extraia este ZIP e utilize a pasta **60mais_saude_app** como raiz do site.
2. Publique todo o conteúdo dessa pasta em serviço de hospedagem estática com HTTPS (por exemplo, GitHub Pages ou Netlify). Não publique apenas `index.html`: arquivos em `js/`, `assets/`, o manifesto e o service worker são necessários.
3. No Chrome Android, abra o endereço HTTPS publicado. Toque em **🎙 Falar** e aceite a permissão de microfone se o navegador perguntar.
4. Use **Instalar**, se o Chrome exibir esse botão, ou o menu do navegador **Adicionar à tela inicial / Instalar app**. O botão de instalação depende do navegador.
5. Se o reconhecimento de voz não existir no aparelho, utilize o microfone do teclado (como Gboard) em campos editáveis; a navegação pelos botões continua disponível.

## Limitações
- Um arquivo HTML isolado enviado pelo WhatsApp **não é uma instalação PWA**. O pacote ZIP é um projeto para publicação; não é um APK de Android.
- Não podemos garantir o reconhecimento de fala em todo aparelho: é um recurso opcional do navegador e pode depender de serviço online. A permissão só aparece quando o navegador oferece a API e inicia a captura de áudio.
- A hospedagem pública não foi realizada. É necessário publicar o pacote em um serviço HTTPS sob seu controle.
- Áudio pode ser tratado pelo serviço do fabricante do navegador; não dite dados de saúde sigilosos, documentos ou senhas.
- O conteúdo jurídico é educativo e deve ser revisado antes de uso institucional.

## Arquivos
`index.html` (aplicativo), `manifest.webmanifest` (instalação), `service-worker.js` (cache), `assets/` (imagens e estilos), `js/` (funções), PDF do e-book.
