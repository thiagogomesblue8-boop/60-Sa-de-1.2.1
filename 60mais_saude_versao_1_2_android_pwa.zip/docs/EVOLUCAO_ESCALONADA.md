# 60+ Saúde — Plano de evolução escalonada

## Versão entregue: 1.1 — Acessibilidade ampliada (outubro de 2026)

**Escopo:** guia educativo funcional, offline após instalação como PWA, sem login nem backend. Em dois caminhos: SUS e planos particulares. Navegação acessível, busca de direitos, orientador passo a passo, modelos de solicitações, contatos, fontes oficiais e e-book.

**O que funciona agora:** pesquisa e filtros locais de conteúdo; questionário guiado; instruções personalizadas conforme o tema escolhido; cartas geradas localmente para copiar, imprimir ou salvar; texto ajustável; alto contraste; leitura em voz alta integral e por bloco, com pausa e interrupção; reconhecimento de comandos de voz e ditado opcional quando suportados; links oficiais externos; ligações pelo telefone do dispositivo; app instalável em navegadores compatíveis quando publicado em HTTPS.

**O que esta versão NÃO faz:** não conecta a sistemas de agendamento do SUS, operadoras ou ANS; não acompanha filas, nem apresenta hospitais próximos; não envia reclamações ou documentos; não faz triagem clínica, diagnóstico, consulta médica ou avaliação jurídica individual; não recebe dados pessoais em servidor. Não há notificações automáticas nem chat inteligente.

**Nota sobre voz:** o reconhecimento por microfone depende de suporte do navegador, permissões e possivelmente processamento externo e internet; não é recurso garantido offline. O aplicativo não grava nem envia voz a servidores próprios.

## Fase 2 — Conteúdo editorial e localização (requer curadoria)
- Inserir conteúdos regionais validados por município, organizados no catálogo de conteúdos, com endereços oficiais de UBS, secretarias e ouvidorias.
- Criar processo editorial para atualização periódica e revisão jurídica assinada por responsáveis designados.
- Oferecer Libras, áudio humano, glossário em leitura fácil e revisão de acessibilidade com pessoas idosas reais.
- Incluir testes automatizados de acessibilidade, desempenho e compatibilidade com dispositivos reais.

## Fase 3 — Serviços oficiais (requer autorização e integrações)
- Conectar APIs oficiais de unidades e regulação **somente quando disponíveis e autorizadas**.
- Adicionar acompanhamento de solicitações com consentimento explícito e autenticação segura.
- Fluxos de encaminhamento que possam abrir a ouvidoria no ambiente próprio do órgão, sem prometer protocolo automático.
- Política de privacidade e governança compatíveis com LGPD e segurança para dados de saúde, se forem tratados.

## Fase 4 — Sustentação institucional
- Painel de gestão de conteúdos com versionamento, auditoria, validação jurídica e monitoramento de links.
- Hospedagem HTTPS, métricas agregadas sem identificar pacientes, gestão de vulnerabilidades e plano de continuidade.
- Pilotos com grupos de pessoas idosas, testes de compreensão, melhoria contínua e avaliação de impacto.

## Estrutura atual
```
60mais_saude_app/
  index.html                         interface do aplicativo
  assets/estilos.css                 estilos e recursos de acessibilidade
  assets/icone.svg                   ícone
  assets/capa-ebook.webp             capa ilustrada do e-book
  js/content.js                      conteúdos e canais (dados)
  js/app.js                          navegação e funções (lógica)
  js/voz.js                          comandos, ditado e leitura por bloco
  ebook_60_mais_saude_edicao_completa.pdf
  manifest.webmanifest               instalação do aplicativo
  service-worker.js                  cache offline
  docs/EVOLUCAO_ESCALONADA.md
  LEIA-ME.md
```

## Segurança e privacidade
- Sem cookies de terceiros, anúncios ou ferramentas de rastreamento.
- Fontes oficiais são abertas diretamente em sites dos respectivos órgãos.
- O navegador salva localmente somente o tamanho de fonte e a preferência de contraste. O fornecedor do navegador poderá processar áudio quando o usuário autorizar o microfone.
- Solicitações geradas ficam em memória da página até fechar/atualizar; não há armazenamento em servidor.
- Não se deve inserir CPF, senhas, prontuários ou informações médicas detalhadas no gerador de texto.
- O app não tem vínculo oficial com órgãos públicos e não substitui orientação de profissionais.

## Avisos jurídicos
As informações legais foram redigidas em linguagem educativa com base em legislação brasileira e orientações públicas da ANS e do Ministério da Saúde, verificadas em outubro de 2026. As regras podem ser atualizadas, e direitos concretos dependem de fatos, contratos e normas específicas. Antes de divulgação institucional, realize revisão jurídica, validação editorial, checagem de contatos e testes de acessibilidade.
