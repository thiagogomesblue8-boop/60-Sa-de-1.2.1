"""Gera arquivo único auto-suficiente para abrir offline, com livro incorporado."""
from pathlib import Path
import base64,re
root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text(encoding='utf-8')
css=(root/'assets/estilos.css').read_text(encoding='utf-8')
content=(root/'js/content.js').read_text(encoding='utf-8')
app=(root/'js/app.js').read_text(encoding='utf-8')
book=(root/'ebook_60_mais_saude_edicao_completa.pdf').read_bytes()
cover=(root/'assets/capa-ebook.webp').read_bytes()
icon=(root/'assets/icone.svg').read_bytes()
html=html.replace('<link rel="manifest" href="manifest.webmanifest">','')
html=html.replace('<link rel="apple-touch-icon" href="assets/icone-192.png">','')
html=html.replace('<link rel="icon" type="image/svg+xml" href="assets/icone.svg">',f'<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,{base64.b64encode(icon).decode()}">')
html=html.replace('<link rel="stylesheet" href="assets/estilos.css">','<style>'+css+'</style>')
html=html.replace('<script defer src="js/content.js"></script><script defer src="js/app.js"></script>','<script>'+content+'</script><script>'+app+'</script>')
html=html.replace('src="assets/capa-ebook.webp"','src="data:image/webp;base64,'+base64.b64encode(cover).decode()+'"')
html=html.replace('href="ebook_60_mais_saude_edicao_completa.pdf"','href="data:application/pdf;base64,'+base64.b64encode(book).decode()+'"')
# Remove installation hooks when running from file; PWA is in the package version.
html=html.replace('if(\'serviceWorker\' in navigator && (location.protocol===\'https:\'||location.hostname===\'localhost\'||location.hostname===\'127.0.0.1\'))navigator.serviceWorker.register(\'./service-worker.js\').catch(()=>{});','')
out=root.parent/'60mais_saude_app_arquivo_unico.html'
out.write_text(html,encoding='utf-8')
print('Criado:',out, 'bytes:',out.stat().st_size)
