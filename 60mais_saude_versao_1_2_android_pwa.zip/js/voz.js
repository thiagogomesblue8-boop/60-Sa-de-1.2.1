/* 60+ Saúde: recursos opcionais de acessibilidade por voz.
 * Sem bibliotecas externas e sem envio de dados pelo aplicativo.
 * ATENÇÃO: alguns navegadores usam serviços externos para reconhecimento de fala.
 */
(() => {
 'use strict';
 const $=(selector,base=document)=>base.querySelector(selector);
 const $$=(selector,base=document)=>Array.from(base.querySelectorAll(selector));
 const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
 const content=window.SAUDE60_CONTENT;
 const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
 let recognition=null, recognizerActive=false, currentMode=null, targetInput=null;
 let speechToken=0, utterance=null, paused=false, activeBlock=null, activeButton=null;
 let observer=null, inserting=false;
 let lastMicMode='command', lastMicInput=null, startingMic=false;
 const statusElement=()=>$('#voice-status');
 function status(message){if(statusElement()){statusElement().textContent=message;$('#voice-live').hidden=false}}
 function micEnvironment(){
  const scheme=location.protocol;
  if(scheme==='content:'||scheme==='file:')return 'Você abriu o app como arquivo local (WhatsApp ou gerenciador de arquivos). Abra a versão publicada em HTTPS no Chrome.';
  if(!window.isSecureContext)return 'Esta página não está em um contexto seguro. Publique o app em HTTPS para habilitar o microfone.';
  if(!Recognition)return 'Este navegador não disponibiliza reconhecimento de fala para páginas web. Experimente Chrome atualizado no Android, ou o microfone do teclado.';
  return 'O navegador oferece reconhecimento de fala, mas a autorização pode depender das configurações do site, do sistema e da rede.';
 }
 function showMicHelp(message){status(message);const panel=$('#mic-diagnostics');if(panel){$('#mic-diagnostics-message').textContent=message;$('#mic-environment').textContent=micEnvironment();panel.hidden=false;panel.scrollIntoView({behavior:'smooth',block:'nearest'});}}
 function supportMessage(feature){if(feature==='mic')showMicHelp('O comando de voz não está disponível neste ambiente. Veja abaixo como resolver.');else status('Este navegador não oferece leitura em voz alta. Você ainda pode ler o texto ou usar um leitor de tela.');}
 
 function getVoice(){const vs=window.speechSynthesis.getVoices();return vs.find(v=>v.lang.toLowerCase()==='pt-br')||vs.find(v=>v.lang.toLowerCase().startsWith('pt'))||null}
 function speechText(root){
  if(!root)return '';
  const cloned=root.cloneNode(true);
  $$('[data-voice-control], [aria-hidden="true"], script, style, .wizard-next, .hero-actions, .channel-actions, .letter-actions, .detail-links, .nav-item',cloned).forEach(n=>n.remove());
  $$('input,textarea,select',cloned).forEach(el=>{
   const value=el.value?.trim?.();if(value){el.replaceWith(document.createTextNode(value));}else{el.remove()}
  });
  return (cloned.textContent||'').replace(/\s+/g,' ').replace(/\s+([,.;:!?])/g,'$1').trim();
 }
 function segments(text){
  const parts=text.match(/[^.!?;:]+[.!?;:]?|[^.!?;:]+$/g)||[text];let buf='', out=[];
  for(const raw of parts){const part=raw.trim();if(!part)continue;
   if((buf+' '+part).length>230&&buf){out.push(buf.trim());buf=''}
   if(part.length>230){if(buf){out.push(buf.trim());buf=''}let remaining=part;while(remaining.length>230){let at=remaining.lastIndexOf(' ',220);if(at<80)at=220;out.push(remaining.slice(0,at).trim());remaining=remaining.slice(at).trim()}buf=remaining}
   else buf+=' '+part;
  }
  if(buf.trim())out.push(buf.trim());return out;
 }
 function syncSpeechUI(){
  $('#speak')?.setAttribute('aria-pressed',String(Boolean(activeButton||utterance)));
  $('#pause-speak')?.setAttribute('aria-pressed',String(paused));
  const pause=$('#pause-speak');if(pause)pause.innerHTML=paused?'▶ <span class="tool-word">Continuar</span>':'⏸ <span class="tool-word">Pausar</span>';
  $$('[data-read-block]').forEach(b=>b.setAttribute('aria-pressed',String(b===activeButton)));
 }
 function stopReading({notify=false}={}){
  speechToken++;utterance=null;paused=false;activeButton=null;activeBlock=null;
  if('speechSynthesis' in window)try{window.speechSynthesis.cancel()}catch{}
  syncSpeechUI();if(notify)status('Leitura interrompida. Você pode escolher outro bloco ou continuar navegando.');
 }
 function readText(text,{block=null,button=null,label='conteúdo'}={}){
  if(!('speechSynthesis' in window)){supportMessage('audio');return}
  stopReading();
  const pieces=segments(text.slice(0,25000));
  if(!pieces.length){status('Não encontramos texto para ler neste bloco.');return}
  const token=++speechToken;activeButton=button;activeBlock=block;
  let index=0;
  function next(){
   if(token!==speechToken)return;
   if(index>=pieces.length){utterance=null;activeButton=null;activeBlock=null;paused=false;syncSpeechUI();status('Leitura concluída: '+label+'.');return}
   const u=new SpeechSynthesisUtterance(pieces[index++]);u.lang='pt-BR';u.rate=.88;u.pitch=1;const voice=getVoice();if(voice)u.voice=voice;
   u.onend=()=>{if(token===speechToken)next()};
   u.onerror=e=>{if(token!==speechToken)return;if(e.error==='interrupted'||e.error==='canceled')return;stopReading();status('O navegador interrompeu a leitura. Tente novamente ou use a leitura de tela do aparelho.')};
   utterance=u;try{window.speechSynthesis.speak(u)}catch{stopReading();status('Não foi possível iniciar a leitura neste navegador.');return}syncSpeechUI();
  }
  status('Lendo '+label+'. Toque em “Parar” a qualquer momento.');next();
 }
 function readBlock(el,button){const title=el.querySelector('h1,h2,h3,b,strong')?.textContent?.trim()||el.getAttribute('aria-label')||'o bloco selecionado';readText(speechText(el),{block:el,button,label:title.slice(0,65)})}
 function readPage(){const page=$('.page:not([hidden])');if(!page)return;const copy=page.cloneNode(true);$$('[data-voice-control], [aria-hidden="true"], .footer',copy).forEach(el=>el.remove());readText(speechText(copy),{label:'a página atual'})}
 function pauseToggle(){if(!('speechSynthesis' in window)){supportMessage('audio');return}if(!utterance){status('Inicie uma leitura antes de pausar.');return}
  if(paused){window.speechSynthesis.resume();paused=false;status('Leitura retomada.');}
  else{window.speechSynthesis.pause();paused=true;status('Leitura pausada. Toque em “Continuar” para retomar ou em “Parar” para cancelar.')}syncSpeechUI();
 }
 // Cada seção e cada opção recebeu um par de controles independentes.
 const blocks='.hero-copy,.emergency,.pageheading,.entry-card,.popular,.homelight,.topic-card,.detail,.filterbar,.wizard-head,#wizard-content,.choice,.privacy-note,.letter-form,.letter-preview,.contact-hero,.channel,.source,.faq details,.ebook-copy,.soft-note,.result-info,.recommend-result,.situation-banner';
 function decorateBlock(el){
  if(el.dataset.voiceReady && (el.tagName==='BUTTON' ? el.parentElement?.classList.contains('voice-card-wrap') : Boolean(el.querySelector(':scope > .voice-actions'))))return;el.dataset.voiceReady='true';
  const wrapper=el.tagName==='BUTTON';let node=el;
  if(wrapper){const wrap=document.createElement('div');wrap.className='voice-card-wrap';wrap.dataset.readable='true';el.parentNode.insertBefore(wrap,el);wrap.append(el);node=wrap}
  else el.dataset.readable='true';
  const controls=document.createElement('div');controls.className='voice-actions';controls.setAttribute('data-voice-control','');
  const hear=document.createElement('button');hear.type='button';hear.className='voice-action';hear.dataset.readBlock='true';hear.setAttribute('aria-pressed','false');hear.textContent='▶ Ouvir bloco';
  const stop=document.createElement('button');stop.type='button';stop.className='voice-action stop-voice-action';stop.dataset.stopBlock='true';stop.textContent='■ Parar';
  const heading=el.querySelector('h1,h2,h3,strong,b')?.textContent?.replace(/\s+/g,' ').trim()||el.textContent.replace(/\s+/g,' ').trim().slice(0,45);
  hear.setAttribute('aria-label','Ouvir este bloco: '+heading.slice(0,80));stop.setAttribute('aria-label','Parar leitura do bloco: '+heading.slice(0,80));
  controls.append(hear,stop);node.append(controls);
 }
 function decorateAll(){if(inserting)return;inserting=true;try{$$(blocks,$('#main')).forEach(decorateBlock)}finally{inserting=false}}
 function setMicUI(on){const c=$('#voice-command');if(c){c.setAttribute('aria-pressed',String(on&&currentMode==='command'));c.innerHTML=on&&currentMode==='command'?'🔴 <span class="tool-word">Ouvindo</span>':'🎙 <span class="tool-word">Falar</span>'}
  $$('[data-dictate]').forEach(b=>{const selected=on&&currentMode==='dictate'&&b.dataset.dictate===targetInput?.id;b.setAttribute('aria-pressed',String(Boolean(selected)));b.textContent=selected?'🔴 Ouvindo...':'🎙 '+(b.dataset.dictate==='search-topics'?'Ditar busca':'Ditar neste campo')})
 }
 function stopMic({notify=false}={}){if(recognition){try{recognition.abort()}catch{}}recognition=null;recognizerActive=false;currentMode=null;targetInput=null;setMicUI(false);if(notify)status('Microfone desligado.')}
 function startMic(mode,input=null){
  lastMicMode=mode;lastMicInput=input;
  if(recognizerActive){stopMic({notify:true});return}
  if(!window.isSecureContext || location.protocol==='file:' || location.protocol==='content:'){showMicHelp('O microfone não pode ser iniciado com segurança a partir deste arquivo. Abra o aplicativo publicado em HTTPS no Chrome.');return}
  if(!Recognition){supportMessage('mic');return}
  stopReading();
  currentMode=mode;targetInput=input;const r=new Recognition();recognition=r;recognizerActive=true;r.lang='pt-BR';r.continuous=false;r.interimResults=false;r.maxAlternatives=1;
  r.onstart=()=>{startingMic=false;$('#mic-diagnostics')?.setAttribute('hidden','');status(mode==='dictate'?'Microfone ligado. Fale devagar: o texto será colocado no campo escolhido.':'Microfone ligado. Diga, por exemplo: “abrir direitos”, “buscar medicamentos” ou “ouvir a página”.');setMicUI(true)};
  r.onresult=e=>{const transcript=String(e.results?.[0]?.[0]?.transcript||'').trim();if(!transcript)return;
   if(mode==='dictate'&&input){if(input.isConnected){const append=input.tagName==='TEXTAREA';input.value=append&&input.value.trim()?input.value.trim()+' '+transcript:transcript;input.dispatchEvent(new Event('input',{bubbles:true}));input.focus();status('Você disse: “'+transcript+'”. Confira o texto antes de continuar.')}else status('O campo foi alterado; toque novamente no microfone para ditar.')}
   else{status('Comando reconhecido: “'+transcript+'”.');setTimeout(()=>handleCommand(transcript),150)}
  };
  r.onerror=e=>{startingMic=false;const messages={'not-allowed':'O acesso à voz foi negado ou bloqueado. Verifique as permissões de microfone do Chrome e do site.','service-not-allowed':'O serviço de reconhecimento de fala foi bloqueado neste navegador.','network':'Não foi possível conectar ao reconhecimento de fala. Verifique a internet e tente novamente.','no-speech':'Nenhuma fala foi reconhecida. Toque no microfone e tente novamente.','audio-capture':'Microfone não encontrado. Verifique o dispositivo.','aborted':''};if(messages[e.error]!==undefined){if(messages[e.error])showMicHelp(messages[e.error])}else showMicHelp('Não foi possível reconhecer sua voz (erro: '+String(e.error||'desconhecido')+').');};
  r.onend=()=>{if(recognition===r){recognizerActive=false;recognition=null;currentMode=null;targetInput=null;setMicUI(false)}};
  try{startingMic=true;r.start()}catch(e){startingMic=false;stopMic();showMicHelp('Não foi possível ativar o microfone neste dispositivo: '+(e?.name||'erro desconhecido')+'.')}
 }
 function clickPage(page){const b=$(`[data-page="${page}"]`);if(b){b.click();status('Página aberta: '+b.textContent.trim()+'.');return true}return false}
 function selectWizard(matcher){const buttons=$$('#wizard-content button[data-w-area],#wizard-content button[data-w-topic],#wizard-content button[data-w-emergency]');const btn=buttons.find(b=>matcher(normalize(b.textContent),b));if(btn){btn.click();status('Opção selecionada: '+btn.textContent.replace(/\s+/g,' ').trim()+'.');return true}return false}
 function findTopic(q){const n=normalize(q);if(n.length<3)return null;const tokens=n.split(' ').filter(w=>w.length>3);return content?.topics?.find(t=>normalize(t.title)===n)||content?.topics?.find(t=>normalize(t.title).includes(n))||content?.topics?.find(t=>tokens.some(x=>normalize(t.title).includes(x)))||null}
 function handleCommand(raw){const q=normalize(raw);if(!q)return;
  if(/^(pare|parar|interromper|silencio|chega|parar leitura|pare de ler)/.test(q)){stopReading({notify:true});return}
  if(/(continuar|retomar|despausar) (a )?(leitura|voz)|^continuar leitura$/.test(q)){if(paused)pauseToggle();else status('Não há leitura pausada. Toque em “Ouvir” para começar.');return}
  if(/(pausar|pause) (a )?(leitura|voz)/.test(q)){if(!paused)pauseToggle();return}
  if(/^(ouvir|ler|leia|falar) (a )?(pagina|tela|tudo|conteudo)/.test(q)){readPage();return}
  if(/^ouvir bloco |^ler bloco /.test(q)){const part=q.replace(/^(ouvir|ler) bloco /,'');const candidates=$$('[data-readable]',$('.page:not([hidden])'));const target=candidates.find(el=>normalize(el.textContent).includes(part));if(target){readBlock(target,$('[data-read-block]',target));return}status('Não encontrei esse bloco. Use o botão “Ouvir bloco” ao lado do conteúdo.');return}
  const routes=[[/\b(inicio|pagina inicial|voltar para casa)\b/,'inicio'],[/\b(direitos|meus direitos|conhecer direitos)\b/,'direitos'],[/\b(resolver|orientador|tenho um problema|preciso de ajuda)\b/,'orientador'],[/\b(solicitacao|reclamacao|criar documento|criar texto|formulario)\b/,'modelos'],[/\b(contato|contatos|telefone|telefones|ouvidoria|ajuda e contatos)\b/,'ajuda'],[/\b(biblioteca|leis|perguntas frequentes)\b/,'biblioteca'],[/\b(ebook|livro digital|livro)\b/,'ebook']];
  if(q.startsWith('buscar ')||q.startsWith('pesquisar ')||q.startsWith('procurar ')){const search=raw.replace(/^\s*(buscar|pesquisar|procurar)\s+/i,'');clickPage('direitos');const field=$('#search-topics');field.value=search;field.dispatchEvent(new Event('input',{bubbles:true}));field.focus();status('Pesquisando: '+search+'. Confira os resultados encontrados.');return}
  if($('#page-orientador')&&!$('#page-orientador').hidden){
   if($('#wizard-content [data-w-area]')){if(/plano|particular|convenio/.test(q)&&selectWizard((n,b)=>b.dataset.wArea==='plano'))return;if(/sus|publico/.test(q)&&selectWizard((n,b)=>b.dataset.wArea==='sus'))return}
   if($('#wizard-content [data-w-emergency]')){if(/^(sim|preciso de socorro|emergencia|urgencia)/.test(q)&&selectWizard((n,b)=>b.dataset.wEmergency==='yes'))return;if(/^(nao|nao e urgencia|sem urgencia)/.test(q)&&selectWizard((n,b)=>b.dataset.wEmergency==='no'))return}
   if($('#wizard-content [data-w-topic]')){const t=findTopic(q);if(t&&selectWizard((n,b)=>b.dataset.wTopic===t.id))return}
   if(/voltar|anterior/.test(q)){const b=$('[data-w-back]');if(b){b.click();status('Voltei para a pergunta anterior.');return}}
  }
  if($('#page-modelos')&&!$('#page-modelos').hidden){
   const area=$('#letter-area');if(/plano|convenio|operadora/.test(q)&&q.length<42){area.value='plano';status('Selecionado: plano de saúde.');return}if(/sus|publico/.test(q)&&q.length<42){area.value='sus';status('Selecionado: SUS.');return}
   const reasons={consulta:/consulta|exame|procedimento/,negativa:/negativa|recusa|cobertura/,medicamento:/remedio|medicamento/,reajuste:/reajuste|mensalidade|aumento/,respeito:/desrespeito|violencia/,outro:/outro/};for(const [key,re] of Object.entries(reasons)){if(re.test(q)&&q.length<48){$('#letter-reason').value=key;status('Motivo selecionado: '+$('#letter-reason').selectedOptions[0].text+'.');return}}
  }
  for(const [pattern,route] of routes){if(pattern.test(q)){clickPage(route);return}}
  const t=findTopic(q);if(t){clickPage('direitos');const search=$('#search-topics');search.value=t.title;search.dispatchEvent(new Event('input',{bubbles:true}));const target=$(`[data-topic="${t.id}"]`);if(target){target.click();status('Assunto aberto: '+t.title+'.');return}}
  status('Não compreendi esse comando. Experimente “abrir direitos”, “buscar consultas”, “ler a página” ou use os botões da tela.');
 }
 function addFieldMics(){['letter-location','letter-details','letter-protocol'].forEach(id=>{const target=$('#'+id);if(!target||$(`[data-dictate="${id}"]`))return;const b=document.createElement('button');b.type='button';b.className='dictate-button field-dictate-button';b.dataset.dictate=id;b.textContent='🎙 Ditar neste campo';b.setAttribute('aria-label','Ditar pelo microfone no campo: '+target.closest('label')?.textContent.trim());target.closest('label').insertAdjacentElement('afterend',b)})}
 function bind(){
  const main=$('#main');if(!main)return;
  decorateAll();observer=new MutationObserver(records=>{
   // Ignora alterações dos controles: evita observar infinitamente a própria decoração.
   if(records.some(r=>Array.from(r.addedNodes).some(n=>n.nodeType===1&&!n.matches?.('[data-voice-control], .voice-actions, .voice-action')&&!n.closest?.('[data-voice-control]'))))decorateAll()
  });observer.observe(main,{childList:true,subtree:true});
  addFieldMics();
  document.addEventListener('click',e=>{
   const read=e.target.closest('[data-read-block]');if(read){e.preventDefault();e.stopPropagation();const el=read.closest('[data-readable]');if(el)readBlock(el,read);return}
   if(e.target.closest('[data-stop-block]')){e.preventDefault();e.stopPropagation();stopReading({notify:true});return}
   const dictate=e.target.closest('[data-dictate]');if(dictate){e.preventDefault();e.stopPropagation();startMic('dictate',$('#'+dictate.dataset.dictate));return}
  },true);
  $('#voice-command')?.addEventListener('click',()=>startMic('command'));
  $('#mic-close')?.addEventListener('click',()=>$('#mic-diagnostics').hidden=true);
  $('#mic-try-again')?.addEventListener('click',()=>startMic(lastMicMode,lastMicInput));
  $('#pause-speak')?.addEventListener('click',pauseToggle);
  $('#voice-help')?.addEventListener('click',()=>$('#voice-help-dialog').showModal());
  $('#close-voice-help')?.addEventListener('click',()=>$('#voice-help-dialog').close());
  $('#voice-help-ok')?.addEventListener('click',()=>$('#voice-help-dialog').close());
  $('#voice-dismiss')?.addEventListener('click',()=>{$('#voice-live').hidden=true});
  // A leitura da página e o comando de parar são disparados pelo app principal.
  // Se o usuário sair de uma página, interrompe também a transcrição ativa.
  document.addEventListener('click',e=>{if(e.target.closest('[data-go],[data-page]')&&recognizerActive)stopMic()},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(recognizerActive)stopMic({notify:true});if(utterance)stopReading({notify:true})}});
  if(!Recognition || !window.isSecureContext || ['file:','content:'].includes(location.protocol))status('A leitura por blocos está disponível. Comandos de voz precisam de navegador compatível e acesso seguro em HTTPS; toque em Falar para ver instruções.');
  if(!('speechSynthesis' in window))status('Este navegador não oferece leitura em voz alta. Você ainda pode utilizar navegação, fonte ampliada e contraste.');
 }
 window.SAUDE60_VOICE={readPage,stopReading,readBlock,pauseToggle,handleCommand};
 document.readyState==='loading'?document.addEventListener('DOMContentLoaded',bind):bind();
})();
