/* Cache básico. Não intercepta nem armazena dados de formulário. */
const CACHE='saude60-v1.2.0-android';
const LOCAL=['./','./index.html','./assets/estilos.css','./assets/icone.svg','./assets/icone-192.png','./assets/icone-512.png','./assets/capa-ebook.webp','./js/content.js','./js/app.js','./js/voz.js','./manifest.webmanifest','./ebook_60_mais_saude_edicao_completa.pdf'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(LOCAL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return; e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(res=>{if(res.ok){const cp=res.clone();caches.open(CACHE).then(c=>c.put(e.request,cp));}return res;})));});
