/* 60+ Saúde — Aplicativo web progressivo (PWA) sem backend e sem rastreadores. */
(() => {
'use strict';
const DB=window.SAUDE60_CONTENT;
const $=(sel,ctx=document)=>ctx.querySelector(sel);
const $$=(sel,ctx=document)=>Array.from(ctx.querySelectorAll(sel));
const clean=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const state={page:'inicio',filter:'ambos',search:'',font:1,contrast:false,wizard:{step:1,area:null,topic:null,emergency:null},letter:''};
let toastTimer;
function saved(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}}
function persist(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3400)}
function navigate(page,{focus=true}={}){
 if(!$('#page-'+page))page='inicio';
 stopSpeech();state.page=page;
 $$('[data-screen]').forEach(el=>el.hidden=el.dataset.screen!==page);
 $$('.nav-item').forEach(b=>{const selected=b.dataset.page===page;b.classList.toggle('active',selected);selected?b.setAttribute('aria-current','page'):b.removeAttribute('aria-current')});
 const titleMap={inicio:'Bem-vindo ao seu guia de direitos',direitos:'Meus direitos',orientador:'Resolver um problema',modelos:'Criar solicitação',ajuda:'Contatos úteis',biblioteca:'Biblioteca de leis',ebook:'E-book 60+ Saúde'};
 $('#current-area').textContent=titleMap[page]||'';
 if(location.hash!=='#'+page) history.replaceState(null,'','#'+page);
 window.scrollTo({top:0,behavior:'instant'});
 if(focus)$('#main').focus({preventScroll:true});
}
function filterTopics(){
 const matched=DB.topics.filter(t=>(state.filter==='ambos'||t.kind.includes(state.filter)||t.kind.includes('ambos'))&&norm([t.title,t.summary,t.intro,...t.steps].join(' ')).includes(norm(state.search)));
 $('#results-count').textContent=matched.length+' '+(matched.length===1?'assunto encontrado':'assuntos encontrados');
 $('#topic-list').innerHTML=matched.length? matched.map(t=>`<button class="topic-card" data-topic="${t.id}"><span class="ticon" aria-hidden="true">${clean(t.icon)}</span><span><b>${clean(t.title)}</b><small>${clean(t.summary)}</small><span class="topic-tag">${t.kind.includes('ambos')?'TODOS':t.kind.includes('sus')?'SUS':'PLANOS PARTICULARES'}</span></span></button>`).join(''):'<div class="soft-note">Não encontramos esse termo. Experimente uma palavra diferente ou veja todos os assuntos.</div>';
 $$('[data-filter]').forEach(b=>{const yes=b.dataset.filter===state.filter;b.classList.toggle('selected',yes);b.setAttribute('aria-pressed',String(yes))});
}
function topicHTML(t){return `<div class="detail-head"><span class="overline">ORIENTAÇÃO SOBRE SEU DIREITO</span><button class="link-button" data-close-topic>Fechar ×</button></div><h2>${clean(t.title)}</h2><p>${clean(t.intro)}</p><h3>O que fazer, passo a passo</h3><ol>${t.steps.map(s=>`<li>${clean(s)}</li>`).join('')}</ol><h3>Documentos que podem ajudar</h3><ul>${t.documents.map(s=>`<li>${clean(s)}</li>`).join('')}</ul><div class="detail-caution"><strong>Atenção:</strong> ${clean(t.caution)}</div><h3>Base legal e fontes oficiais</h3><div class="detail-links">${t.law.map(id=>DB.sources[id]?`<a href="${DB.sources[id].url}" target="_blank" rel="noopener noreferrer">${clean(DB.sources[id].name)} ↗</a>`:'').join('')}</div><div class="wizard-next"><button class="button primary" data-go="orientador">Quero ajuda com meu caso →</button><button class="button muted" data-go="modelos">Criar solicitação</button></div>`}
function openTopic(id){const t=DB.topics.find(x=>x.id===id);if(!t)return;navigate('direitos',{focus:false});const detail=$('#topic-detail');detail.innerHTML=topicHTML(t);detail.hidden=false;detail.scrollIntoView({behavior:'smooth',block:'start'});detail.setAttribute('tabindex','-1');detail.focus({preventScroll:true})}
function renderPopular(){const ids=['prioridade','consulta-sus','plano-cobertura','medicamentos-sus','plano-reajuste','acompanhante'];$('#popular-topics').innerHTML=ids.map(id=>{const t=DB.topics.find(x=>x.id===id);return `<button class="popular" data-topic="${id}"><span class="picon" aria-hidden="true">${clean(t.icon)}</span><span><strong>${clean(t.title)}</strong><small>${clean(t.summary)}</small></span></button>`}).join('')}
function renderChannels(){
 const labels={emergency:'Urgência',sus:'SUS',plano:'Plano de saúde',protection:'Proteção',general:'Apoio jurídico'};
 $('#channel-list').innerHTML=DB.channels.map(ch=>`<article class="channel"><div class="channel-top"><h2>${clean(ch.name)}</h2><span class="channel-kind">${labels[ch.kind]||'Contato'}</span></div><div class="number">${clean(ch.number)}</div><p>${clean(ch.desc)}</p><div class="channel-actions">${ch.href?`<a class="button primary" href="${ch.href}">Ligar agora ↗</a>`:''}<a class="button muted" href="${ch.online}" target="_blank" rel="noopener noreferrer">${clean(ch.onlineLabel)} ↗</a></div></article>`).join('');
}
function renderLibrary(){
 $('#source-list').innerHTML=Object.entries(DB.sources).map(([id,s])=>`<article class="source"><h3>${clean(s.name)}</h3><p>${clean(s.body)}</p><a href="${s.url}" target="_blank" rel="noopener noreferrer">Acessar fonte oficial ↗</a></article>`).join('');
 $('#faq-list').innerHTML=DB.faqs.map(f=>`<details><summary>${clean(f.q)}</summary><p>${clean(f.a)}</p></details>`).join('');
}
function resetWizard(area=null){state.wizard={step:area?2:1,area,topic:null,emergency:null};renderWizard()}
function renderWizard(){
 const w=state.wizard;const p=Math.min(w.step,3);
 $('#step-marker').textContent=w.step===4?'ORIENTAÇÃO PRONTA':`ETAPA ${p} DE 3`;
 $('#wizard .progress').setAttribute('aria-valuenow',String(p));$('#progress-fill').style.width=(p*100/3)+'%';
 let html='';
 if(w.step===1){html=`<h2>Onde você precisa de ajuda?</h2><p class="step-desc">Selecione o tipo de serviço. Se você tem plano, também pode usar o SUS.</p><div class="choice-grid"><button class="choice" data-w-area="sus"><span class="choice-icon">✚</span> Serviço público (SUS) →</button><button class="choice" data-w-area="plano"><span class="choice-icon">✥</span> Plano de saúde particular →</button></div>`}
 else if(w.step===2){const list=DB.topics.filter(t=>t.kind.includes(w.area)||t.kind.includes('ambos'));html=`<h2>O que aconteceu?</h2><p class="step-desc">Escolha a situação mais parecida com a sua.</p><div class="choice-grid">${list.map(t=>`<button class="choice" data-w-topic="${t.id}"><span class="choice-icon" aria-hidden="true">${clean(t.icon)}</span>${clean(t.title)} →</button>`).join('')}</div><div class="wizard-next"><button class="button muted" data-w-back>← Voltar</button></div>`}
 else if(w.step===3){html=`<h2>O problema é uma urgência de saúde agora?</h2><p class="step-desc">Exemplos de sinais graves: dor forte no peito, falta de ar importante, desmaio ou sinais súbitos de AVC. O aplicativo não avalia sua condição.</p><div class="choice-grid"><button class="choice" data-w-emergency="yes"><span class="choice-icon" aria-hidden="true">!</span> Sim, preciso de socorro agora</button><button class="choice" data-w-emergency="no"><span class="choice-icon" aria-hidden="true">✓</span> Não, quero as orientações</button></div><div class="wizard-next"><button class="button muted" data-w-back>← Voltar</button></div>`}
 else {const t=DB.topics.find(x=>x.id===w.topic);if(w.emergency){html=`<div class="situation-banner"><h2>Procure ajuda imediatamente</h2><p>Se há sinais de gravidade, não espere uma autorização, reclamação ou resposta deste aplicativo. Procure serviço de urgência. Quando for necessário socorro móvel, ligue para o <strong>SAMU 192</strong>.</p><a class="button emergency-button" href="tel:192">Ligar para 192 ↗</a></div><div class="wizard-next"><button class="button muted" data-w-back>← Revisar resposta</button><button class="button muted" data-go="ajuda">Outros contatos</button></div>`}
 else if(t){html=`<div class="result-info"><strong>Seu roteiro está pronto!</strong><p>Veja os próximos passos para buscar orientação sobre <strong>${clean(t.title)}</strong>.</p></div><div class="recommend-result"><h3>O que fazer</h3><ol>${t.steps.map(s=>`<li>${clean(s)}</li>`).join('')}</ol><div class="detail-caution"><strong>Importante:</strong> ${clean(t.caution)}</div><h3>Documentos úteis</h3><ul>${t.documents.map(s=>`<li>${clean(s)}</li>`).join('')}</ul><div class="detail-links">${t.law.map(id=>`<a href="${DB.sources[id].url}" target="_blank" rel="noopener noreferrer">${clean(DB.sources[id].name)} ↗</a>`).join('')}</div></div><div class="wizard-next"><button class="button primary" data-go="modelos">Criar uma solicitação →</button><button class="button muted" data-go="ajuda">Ver canais oficiais</button><button class="button muted" data-w-back>← Voltar</button></div>`}}
 $('#wizard-content').innerHTML=html;
}
function buildLetter(e){e.preventDefault();
 const area=$('#letter-area').value,reason=$('#letter-reason').value,service=$('#letter-location').value.trim(),details=$('#letter-details').value.trim(),protocol=$('#letter-protocol').value.trim(),date=$('#letter-date').value;
 const reasons={consulta:'dificuldade de agendamento ou realização de consulta, exame ou procedimento',negativa:'negativa de atendimento ou de cobertura',medicamento:'dificuldade de acesso a medicamento',reajuste:'reajuste de mensalidade',respeito:'atendimento desrespeitoso',outro:'problema relacionado ao atendimento à saúde'};
 const d=date?new Date(date+'T12:00:00').toLocaleDateString('pt-BR'):'';
 const target=area==='plano'?'À operadora de plano de saúde / setor de atendimento ao beneficiário':'À unidade de saúde / Secretaria de Saúde / Ouvidoria do SUS';
 const requests=area==='plano'?'Peço resposta clara, fundamentada e documentada, com indicação de eventuais cláusulas ou regras aplicáveis, bem como as providências para solucionar o caso.':'Peço esclarecimentos e encaminhamento adequado, com informações sobre as medidas e orientações disponíveis.';
 state.letter=`SOLICITAÇÃO DE INFORMAÇÕES / REGISTRO DE RECLAMAÇÃO\n\nDestinatário: ${target}\nAssunto: ${reasons[reason]}\n${service?'Serviço ou operadora: '+service+'\n':''}${d?'Data aproximada do ocorrido: '+d+'\n':''}${protocol?'Protocolo informado: '+protocol+'\n':''}\nPrezados(as),\n\nVenho solicitar informações e providências sobre ${reasons[reason]}.${details?'\n\nRelato: '+details:''}\n\n${requests}\n\nSolicito, se possível, número de protocolo e resposta por um canal oficial.\n\nAtenciosamente,\n[Nome do solicitante]\n[Data da solicitação]\n\nEste texto é um modelo educativo gerado no 60+ Saúde. Não foi enviado automaticamente.`;
 $('#letter-result').textContent=state.letter;$('#letter-result').hidden=false;$('#letter-help').hidden=true;$('#letter-actions').hidden=false;$('#letter-result').focus();toast('Seu texto foi gerado. Revise antes de enviar.');
}
async function copyText(text){try{await navigator.clipboard.writeText(text);toast('Texto copiado!')}catch{const el=document.createElement('textarea');el.value=text;el.style.position='fixed';el.style.opacity='0';document.body.append(el);el.select();try{document.execCommand('copy');toast('Texto copiado!')}catch{toast('Não foi possível copiar. Selecione o texto e copie manualmente.')}el.remove()}}
function downloadLetter(){if(!state.letter)return;const blob=new Blob(['\ufeff'+state.letter],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='solicitacao_60_mais_saude.txt';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Arquivo de texto preparado para salvar.')}
function stopSpeech(){if(window.SAUDE60_VOICE){window.SAUDE60_VOICE.stopReading();return}if('speechSynthesis' in window){window.speechSynthesis.cancel();$('#speak')?.setAttribute('aria-pressed','false')}}
function speak(){if(window.SAUDE60_VOICE){window.SAUDE60_VOICE.readPage();return}toast('Leitura em voz alta indisponível neste navegador.')}
function fontSet(newval){state.font=Math.min(1.35,Math.max(.9,Math.round(newval*100)/100));document.documentElement.style.setProperty('--fontscale',state.font);persist('60-font',state.font);toast(state.font>1?'Texto ampliado':'Tamanho do texto ajustado')}
function contrastToggle(){state.contrast=!state.contrast;document.body.classList.toggle('high-contrast',state.contrast);$('#contrast').setAttribute('aria-pressed',String(state.contrast));persist('60-contrast',state.contrast);toast(state.contrast?'Alto contraste ativado':'Alto contraste desativado')}
function events(){
 document.addEventListener('click',e=>{
  const nav=e.target.closest('[data-page]');if(nav){navigate(nav.dataset.page);return}
  const go=e.target.closest('[data-go]');if(go){navigate(go.dataset.go);return}
  const t=e.target.closest('[data-topic]');if(t){openTopic(t.dataset.topic);return}
  if(e.target.closest('[data-close-topic]')){$('#topic-detail').hidden=true;$('#topic-list').scrollIntoView({behavior:'smooth'});return}
  const f=e.target.closest('[data-filter]');if(f){state.filter=f.dataset.filter;$('#topic-detail').hidden=true;filterTopics();return}
  const s=e.target.closest('[data-start]');if(s){navigate('orientador');resetWizard(s.dataset.start);return}
  const area=e.target.closest('[data-w-area]');if(area){state.wizard.area=area.dataset.wArea;state.wizard.step=2;renderWizard();return}
  const selected=e.target.closest('[data-w-topic]');if(selected){state.wizard.topic=selected.dataset.wTopic;state.wizard.step=3;renderWizard();return}
  const emergency=e.target.closest('[data-w-emergency]');if(emergency){state.wizard.emergency=emergency.dataset.wEmergency==='yes';state.wizard.step=4;renderWizard();return}
  if(e.target.closest('[data-w-back]')){state.wizard.step=Math.max(1,state.wizard.step-1);renderWizard();return}
  if(e.target.closest('[data-open="about"]')){$('#about-dialog').showModal();return}
 });
 $('#search-topics').addEventListener('input',e=>{state.search=e.target.value;$('#topic-detail').hidden=true;filterTopics()});
 $('#wizard-reset').addEventListener('click',()=>resetWizard());
 $('#font-up').addEventListener('click',()=>fontSet(state.font+.1));
 $('#font-down').addEventListener('click',()=>fontSet(state.font-.1));
 $('#contrast').addEventListener('click',contrastToggle);
 $('#speak').addEventListener('click',speak);
 $('#stop-speak').addEventListener('click',()=>{stopSpeech();toast('Leitura interrompida.')});
 $('#letter-form').addEventListener('submit',buildLetter);
 $('#letter-copy').addEventListener('click',()=>copyText(state.letter));
 $('#letter-download').addEventListener('click',downloadLetter);
 $('#letter-print').addEventListener('click',()=>window.print());
 $('#close-about').addEventListener('click',()=>$('#about-dialog').close());
 $('#about-ok').addEventListener('click',()=>$('#about-dialog').close());
 window.addEventListener('hashchange',()=>{let page=location.hash.replace(/^#/,'').split('/')[0];if($('#page-'+page))navigate(page)});
}
function init(){
 state.font=saved('60-font',1);state.font=typeof state.font==='number'?Math.min(1.35,Math.max(.9,state.font)):1;document.documentElement.style.setProperty('--fontscale',state.font);
 state.contrast=saved('60-contrast',false)===true;document.body.classList.toggle('high-contrast',state.contrast);$('#contrast').setAttribute('aria-pressed',String(state.contrast));
 renderPopular();renderChannels();renderLibrary();filterTopics();renderWizard();events();
 navigate(location.hash.replace(/^#/,'')||'inicio',{focus:false});
 if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'))navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
}
document.readyState==='loading'?document.addEventListener('DOMContentLoaded',init):init();
})();

// Instalação PWA: mostra opção apenas se o navegador fornecer um evento de instalação real.
(()=>{let pending=null;const btn=document.getElementById('install-app');if(!btn)return;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();pending=e;btn.hidden=false;});
window.addEventListener('appinstalled',()=>{pending=null;btn.hidden=true;});
btn.addEventListener('click',async()=>{if(!pending)return;const evt=pending;pending=null;btn.hidden=true;try{await evt.prompt();await evt.userChoice;}catch(e){console.warn('Instalação não disponível',e)}});})();
